## Dropdown Menu 

Animated multi-level dropdown menu inspired by Facebook's March 2020 web UI. 

Watch the full [React dropdown tutorial](https://youtu.be/IF6k0uZuypA) on YouTube. 

```
git clone <this-repo>

npm i
npm start
```